package com.demo;

public class Customer 
{
	@Override
	public String toString() 
	{
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail=" + customerEmail + "]";
	} 
	
	public Customer(int customerId, String customerName, String customerEmail, Order orderObject) 
	{
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.orderObject = orderObject;
	}
	
	private int customerId;
	private String customerName;
	private String customerEmail;
	private Order orderObject;
	
	public int getCustomerId() 
	{
		return customerId;
	}
	
	public void setCustomerId(int customerId) 
	{
		this.customerId = customerId;
	}

	public String getCustomerName() 
	{
		return customerName;
	}

	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}

	public String getCustomerEmail() 
	{
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) 
	{
		this.customerEmail = customerEmail;
	}

	public Order getOrderObject() 
	{
		return orderObject;
	}

	public void setOrderObject(Order orderObject) 
	{
		this.orderObject = orderObject;
	}
}
