package com.demo;

import lombok.Data;

@Data // Creating class with lombok just type @Data before class.
public class Order 
{
	public Order(int orderid, int orderdetails) 
	{
		super();
		this.orderid = orderid;
		this.orderdetails = orderdetails;
	}

	private int orderid;
	private int orderdetails;
	
	public int getOrderid() 
	{
		return orderid;
	}
	
	public void setOrderid(int orderid) 
	{
		this.orderid = orderid;
	}
	
	public int getOrderdetails() 
	{
		return orderdetails;
	}
	
	public void setOrderdetails(int orderdetails) 
	{
		this.orderdetails = orderdetails;
	}
}
