package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        Customer customer = (Customer) context.getBean("cust");
        customer.toString();
        System.out.println(customer.getCustomerId());
        System.out.println(customer.getCustomerName());
        System.out.println(customer.getCustomerEmail());
        System.out.println(customer.getOrderObject());
    }
}

/*
    We have to create a object of class implementing ApplicationContext interface.
    context.getBean("") return object type so type casting is must.
	ctrl + shift + o = all the packages used in the file will get imported.
	ctrl + shift + f = formatting of code.
*/



