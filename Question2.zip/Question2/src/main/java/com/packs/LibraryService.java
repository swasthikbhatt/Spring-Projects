package com.packs;
import java.util.List;

public class LibraryService 
{
	private List<Book> book;
	
	public List<Book> getBook() 
	{
		return book;
	}
	
	public void setBook(List<Book> book) 
	{
		this.book = book;
	}
	
	public void display()
	{
		for(Book b : book)
		{
			System.out.println("Title : " + b.getTitle());
		}
	}
}
