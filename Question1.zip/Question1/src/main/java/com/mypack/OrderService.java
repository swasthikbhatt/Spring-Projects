package com.mypack;

public class OrderService 
{
	private PaymentService ps;

	public PaymentService getPs() 
	{
		return ps;
	}

	public void setPs(PaymentService ps) 
	{
		this.ps = ps;
	}
	
	public void placeOrder(double amount) 
	{
		 System.out.println("Order placed for " + amount + " Rs");
		 ps.processPayment(amount);
	}
}


