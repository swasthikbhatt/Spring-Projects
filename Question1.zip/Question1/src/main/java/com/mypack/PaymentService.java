package com.mypack;

public class PaymentService 
{
	public void processPayment(double amount) 
	{
		System.out.println("Processing payment of " + amount + " Rs");
	}
}


