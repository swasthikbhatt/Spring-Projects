package in.smartprogramming.beans;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
// import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
// @Component("msgObject166")
@Lazy
// @Scope("prototype") --> Lazy loadng apply for Sngleton bean scope, otherwise destroy() method will not be called.

public class Student 
{
	// @Value don't use setter or constructor for setting property.
	@Value("166")
	private int id;
	@Value("Swasthik")
	private String name;
	@Value("swasthikbhatt18@gmail.com")
	private String email;
	
	@Override
	public String toString()
	{
		return "[ " + id + ", " + name + ", " + email + " ]";
	}
	
	public int getId() 
	{
		return id;
	}
	
	public void setId(int id) 
	{
		this.id = id;
		System.out.println("property setting.........." + id);
	}
	
	public String getName() 
	{
		return name;
	}
	
	public void setName(String name) 
	{
		this.name = name;
	}
	
	public String getEmail() 
	{
		return email;
	}
	
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	@PostConstruct
	public void start()
	{
		// How much bean tag is there that much initialization happens.
		System.out.println("Initialization...........");
	}
	
	@PreDestroy
	public void end()
	{
		System.out.println("Destroying...........");
	}
}
