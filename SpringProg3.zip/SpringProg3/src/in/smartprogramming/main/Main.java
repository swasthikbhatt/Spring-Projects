package in.smartprogramming.main;
import in.smartprogramming.beans.Student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

// Annotations using XML configuration.

public class Main
{
	public static void main(String[] args) 
	{
		String config_location = "/in/smartprogramming/resources/ApplicationContext.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(config_location);
		
		Student std = (Student) context.getBean("student");
		
		System.out.println(std);
		System.out.println(std.hashCode());
		System.out.println(std.getId());
		System.out.println(std.getName());
		System.out.println(std.getEmail());	
		
		((ConfigurableApplicationContext)context).close();
	}
}

