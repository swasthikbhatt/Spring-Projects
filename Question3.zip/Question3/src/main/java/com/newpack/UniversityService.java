package com.newpack;

import java.util.List;

public class UniversityService 
{
	private List<Student> students;
	private List<Course> courses;
	
	public List<Student> getStudents() { return students; }
	public void setStudents(List<Student> students) { this.students = students; }
	
	public List<Course> getCourses() { return courses; }
	public void setCourses(List<Course> courses) { this.courses = courses; }
	
	public void enrollStudent(int studentId, int courseId)
	{
		Student studentToEnroll = null;
		Course courseToEnrollIn = null;
		
		for (Student student : students) 
		{
			if (student.getSid() == studentId) 
			{
				studentToEnroll = student;
				break;
			}
		}
		
		for (Course course : courses) 
		{
			if (course.getCourse_id() == courseId) 
			{
				courseToEnrollIn = course;
				break;
			}
		}
		
		if (studentToEnroll != null && courseToEnrollIn != null) 
		{
			System.out.println("Enrolled student " + studentToEnroll.getSname() + " in course " + courseToEnrollIn.getCname());
		} 
		else 
		{
			System.out.println("Student or course not found.");
		}
	}
}









