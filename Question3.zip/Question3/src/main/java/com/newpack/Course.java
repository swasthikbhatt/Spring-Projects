package com.newpack;

public class Course 
{
	private String cname;
	private int course_id;
	
	public Course(String cname, int course_id) 
	{
		this.cname = cname;
		this.course_id = course_id;
	}
	public Course() {}
	
	public String getCname()  { return cname; }
	public void setCname(String cname) { this.cname = cname; }
	
	public int getCourse_id() { return course_id; }
	public void setCourse_id(int course_id) { this.course_id = course_id; }
}

