package com.newpack;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    @SuppressWarnings("resource")
	public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("myconfig.xml");
    	UniversityService universityService = (UniversityService) context.getBean("uni");
    	
    	universityService.enrollStudent(166, 101);
    	universityService.enrollStudent(166, 102);
    	universityService.enrollStudent(167, 101);
    	
    	universityService.enrollStudent(167, 103);
    	universityService.enrollStudent(169, 102);
    	
    	System.out.println(universityService.getStudents());
    	System.out.println(universityService.getCourses());
    }
}


