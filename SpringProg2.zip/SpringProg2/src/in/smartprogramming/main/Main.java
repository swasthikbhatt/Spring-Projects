package in.smartprogramming.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import in.smartprogramming.beans.Student;
import in.smartprogramming.resources.SpringConfig;

public class Main 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		Student std1 = (Student) context.getBean("StudentOb1");
		System.out.println(std1);
		
		Student std2 = context.getBean("StudentOb2", Student.class);
		System.out.println(std2);
		
		// If we don't specify which bean object to get created default i.e primary bean get initialized.
		Student std3 = context.getBean(Student.class);
		System.out.println(std3);
		
		Student std4 = context.getBean("StudentOb3", Student.class);
		System.out.println(std4);
		System.out.println(std4.hashCode());
		
		((AbstractApplicationContext) context).close();
	}
}
