package in.smartprogramming.resources;
import in.smartprogramming.beans.Student;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class SpringConfig 
{
	@Bean
	public Student StudentOb1()
	{
		Student std = new Student();
		std.setId(166);
		std.setName("Swasthik");
		std.setEmail("swasthikbhatt18@gmail.com");
		return std;
	}
	
	@Primary
	@Bean
	public Student StudentOb2()
	{
		Student std = new Student();
		std.setId(167);
		std.setName("Utkarsh");
		std.setEmail("utkarsh@gmail.com");
		return std;
	}
	
	// Ig you don't want to make your bean name as your method name.
	@Bean("StudentOb3")
	public Student someRandomMethodName()
	{
		Student std = new Student();
		std.setId(168);
		std.setName("joywin");
		std.setEmail("joywin@gmail.com");
		return std;
	}
}
