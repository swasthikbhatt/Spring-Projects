package com.infosys.Annotations;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.infosys.beans.Books;
import com.infosys.config.Config;

public class App 
{
    @SuppressWarnings({ "resource" })
	public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
        Books book = context.getBean(Books.class);
        Books childbook = context.getBean("childrenbook", Books.class);
        Books springbook =context.getBean("springbook", Books.class);
        
        System.out.println("children book name : "   + childbook.getBookName());
        System.out.println("spring learning book : " + springbook.getBookName());
        System.out.println("Primary bean data : "    + book.getBookName());
    }
}
