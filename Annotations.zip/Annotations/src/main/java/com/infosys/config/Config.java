package com.infosys.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import com.infosys.beans.Books;

// add annotations in Configuration class using @configuration.
// Create a bean using @Bean and custom method having return-type as Books and set the properties of Book object.
// @Bean indicates that a method produces a bean to be managed by the Spring container.
// @Bean methods and may be processed by the Spring container to generate bean definitions and service requests.
// @Component is mostly commonly used annotation by developers.

@Configuration
public class Config 
{
	@Primary
	@Bean(name="childrenbook")
	public Books getBooksObject()
	{
		Books b = new Books();
		b.setBookId(101);
		b.setBookName("Harry Poter");
		return b;
	}
	
	@Bean(name="springbook")
	public Books getBooksObject1()
	{
		Books b = new Books();
		b.setBookId(102);
		b.setBookName("My published Book");
		return b;
	}
}





